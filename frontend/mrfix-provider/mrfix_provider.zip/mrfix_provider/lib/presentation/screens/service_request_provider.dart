import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../data/datasources/remote_data_source.dart';
import '../../domain/entities/entities.dart';
import '../../core/constants/app_constants.dart';

class ServiceRequestProvider extends ChangeNotifier {
  final RemoteDataSource _ds;

  List<ServiceRequestEntity> _available = [];
  List<ServiceRequestEntity> _myRequests = [];
  List<ServiceCategoryEntity> _categories = [];
  List<ProviderSpecialtyEntity> _mySpecialties = [];
  ServiceRequestEntity? _selected;
  bool _loading = false;
  bool _actionLoading = false;
  String? _error;
  Timer? _timer;
  int _newCount = 0;

  ServiceRequestProvider(this._ds);

  List<ServiceRequestEntity> get availableRequests => _available;
  List<ServiceRequestEntity> get myRequests        => _myRequests;
  List<ServiceCategoryEntity> get categories       => _categories;
  List<ProviderSpecialtyEntity> get mySpecialties  => _mySpecialties;
  ServiceRequestEntity? get selected               => _selected;
  bool get loading                                 => _loading;
  bool get actionLoading                           => _actionLoading;
  String? get error                                => _error;
  int get newRequestCount                          => _newCount;

  // ── Polling ───────────────────────────────────────────────────────────────

  void startPolling() {
    _timer?.cancel();
    _timer = Timer.periodic(
      AppConstants.pollingInterval, (_) => _silentRefresh());
  }

  void stopPolling() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _silentRefresh() async {
    try {
      final prev = _available.length;
      final results = await Future.wait([
        _ds.getAvailableRequests(),
        _ds.getMyRequests(),
      ]);
      _available  = results[0] as List<ServiceRequestEntity>;
      _myRequests = results[1] as List<ServiceRequestEntity>;

      if (_available.length > prev) {
        _newCount += _available.length - prev;
      }

      if (_selected != null) {
        final upd = _myRequests.where((r) => r.id == _selected!.id);
        if (upd.isNotEmpty) _selected = upd.first;
      }
      notifyListeners();
    } catch (_) {}
  }

  // ── Data Loading ──────────────────────────────────────────────────────────

  Future<void> loadAll() async {
    _loading = true; _error = null; notifyListeners();
    try {
      final results = await Future.wait([
        _ds.getAvailableRequests(),
        _ds.getMyRequests(),
      ]);
      _available  = results[0] as List<ServiceRequestEntity>;
      _myRequests = results[1] as List<ServiceRequestEntity>;
      _newCount = 0;
    } catch (e) {
      _error = e.toString();
    }
    _loading = false; notifyListeners();
  }

  Future<void> loadCategories() async {
    try {
      _categories = await _ds.getCategories();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> loadMySpecialties() async {
    try {
      _mySpecialties = await _ds.getMySpecialties();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> loadRequest(String id) async {
    _loading = true; notifyListeners();
    try {
      _selected = await _ds.getRequest(id);
    } catch (e) {
      _error = e.toString();
    }
    _loading = false; notifyListeners();
  }

  // ── Actions ───────────────────────────────────────────────────────────────

  Future<bool> acceptRequest(String id) async {
    _actionLoading = true; _error = null; notifyListeners();
    try {
      final updated = await _ds.updateStatus(id, 'accepted');
      _available = _available.where((r) => r.id != id).toList();
      _addOrUpdate(updated);
      _selected = updated;
      _actionLoading = false; notifyListeners(); return true;
    } catch (e) {
      _error = e.toString();
      _actionLoading = false; notifyListeners(); return false;
    }
  }

  Future<bool> rejectRequest(String id) async {
    _actionLoading = true; notifyListeners();
    try {
      await _ds.updateStatus(id, 'cancelled',
          cancellationReason: 'Recusado pelo prestador');
      _available = _available.where((r) => r.id != id).toList();
      _actionLoading = false; notifyListeners(); return true;
    } catch (e) {
      _error = e.toString();
      _actionLoading = false; notifyListeners(); return false;
    }
  }

  Future<bool> startService(String id) =>
      _updateStatus(id, 'in_progress');

  Future<bool> completeService(String id) =>
      _updateStatus(id, 'completed');

  Future<bool> _updateStatus(String id, String status) async {
    _actionLoading = true; _error = null; notifyListeners();
    try {
      final updated = await _ds.updateStatus(id, status);
      _addOrUpdate(updated);
      _selected = updated;
      _actionLoading = false; notifyListeners(); return true;
    } catch (e) {
      _error = e.toString();
      _actionLoading = false; notifyListeners(); return false;
    }
  }

  Future<bool> addSpecialty({
    required String categoryId,
    double? averagePrice,
    int? experienceYears,
    String? bio,
  }) async {
    _actionLoading = true; _error = null; notifyListeners();
    try {
      final s = await _ds.addSpecialty(
        categoryId: categoryId,
        averagePrice: averagePrice,
        experienceYears: experienceYears,
        bio: bio,
      );
      _mySpecialties = [..._mySpecialties, s];
      _actionLoading = false; notifyListeners(); return true;
    } catch (e) {
      _error = e.toString();
      _actionLoading = false; notifyListeners(); return false;
    }
  }

  Future<bool> submitRating({
    required String requestId,
    required int score,
    String? comment,
  }) async {
    try {
      await _ds.submitRating(
        serviceRequestId: requestId,
        score: score,
        comment: comment,
      );
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners(); return false;
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  void selectRequest(ServiceRequestEntity req) {
    _selected = req;
    notifyListeners();
  }

  void clearNewCount() {
    _newCount = 0;
    notifyListeners();
  }

  void _addOrUpdate(ServiceRequestEntity updated) {
    final exists = _myRequests.any((r) => r.id == updated.id);
    _myRequests = exists
      ? _myRequests
          .map((r) => r.id == updated.id ? updated : r)
          .toList()
      : [updated, ..._myRequests];
  }

  @override
  void dispose() {
    stopPolling();
    super.dispose();
  }
}